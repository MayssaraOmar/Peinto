
//https://java2blog.com/jsonsimple-example-read-and-write-json/
	import java.io.File;
	import java.io.FileWriter;
	import java.io.IOException;
	 
	import org.json.simple.JSONArray;
	import org.json.simple.JSONObject;
	 
	/*
	 * @Author : Arpit Mandliya
	 */
	public class JSONSimpleWritingToFileExample {
	 
	    public static void main(String[] args) {
	 
	        JSONObject countryObj = new JSONObject();
	        countryObj.put("Name", "India");
	        countryObj.put("Population", new Integer(1000000));
	 
	        JSONArray listOfStates = new JSONArray();
	        listOfStates.add("Madhya Pradesh"); //adding to the array
	        listOfStates.add("Maharastra");
	        listOfStates.add("Rajasthan");
	 
	        countryObj.put("States", listOfStates); //(key , value)
	 
	        try {
	            
	            // Writing to a file
	            File file=new File("CountryJSONFile.json");
	            file.createNewFile();
	            FileWriter fileWriter = new FileWriter(file);
	            //System.out.println("Writing JSON object to file");
	            //System.out.println("-----------------------");
	           // System.out.println(countryObj); // first print array second population & number third Name 
	 
	            fileWriter.write(countryObj.toJSONString());
	            //System.out.println(countryObj); //Same printing
	            fileWriter.flush();
	            fileWriter.close();
	 
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	 
	    }
	}
	
