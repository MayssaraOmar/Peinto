import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadFromXML {
	public static void main(String[] args) {
		
		try {
			
			FileInputStream fis = new FileInputStream(new File ("Personne.xml"));
			XMLDecoder decoder = new XMLDecoder (fis);
			
			Person P2 = (Person)decoder.readObject();
			decoder.close();
			fis.close();
			
			System.out.println("FirstName "+ P2.getFirstName());
			System.out.println("LastName "+ P2.getLastName());
			
			System.out.println("Age "+ P2.getAge());
			System.out.println("Height "+ P2.getHeight());
		}
		catch(IOException ex) {
			
			ex.printStackTrace();
			
		}
	}

}
