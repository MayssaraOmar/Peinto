import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class WriteInXML {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person P1= new Person ("John", "Smith", 31, 1.86);
		//ArrayList<Person> obj = new ArrayList<Person>());
		
		
		
		try {
			FileOutputStream fos = new FileOutputStream(new File ("Personne.xml"));
			XMLEncoder encoder = new XMLEncoder (fos);
			encoder.writeObject(P1);
			encoder.close();
			fos.close();
		}
		catch(IOException ex) {
			
			ex.printStackTrace();
			
			
		}

	}

}
