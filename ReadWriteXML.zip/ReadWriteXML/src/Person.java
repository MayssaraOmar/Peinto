
public class Person {
	private String firstName;
	private String LastName;
   private int age;
   private double height;
 
   
   
   public Person() {
	   
   }
   
   
public Person(String firstName, String lastName, int age, double height) {
	
	this.firstName = firstName;
	LastName = lastName;
	this.age = age;
	this.height = height;
	
}


public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return LastName;
}


public void setLastName(String lastName) {
	LastName = lastName;
}


public int getAge() {
	return age;
}


public void setAge(int age) {
	this.age = age;
}


public double getHeight() {
	return height;
}


public void setHeight(double height) {
	this.height = height;
}



   
   
   
   
}
